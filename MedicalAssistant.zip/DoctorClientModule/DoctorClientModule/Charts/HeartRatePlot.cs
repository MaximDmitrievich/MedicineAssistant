﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorClientModule.Charts
{
    public class HeartRatePlot
    {
        public DateTime EventTime { get; set; }
        public double HeartRate { get; set; }
    }
}
