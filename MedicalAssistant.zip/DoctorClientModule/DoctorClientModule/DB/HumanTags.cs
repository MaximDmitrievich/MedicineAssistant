﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorClientModule.DB
{
    public class HumanTags
    {
        public string Emo { get; set; }
        public string Tag { get; set; }
        public string Time { get; set; }
    }
}
